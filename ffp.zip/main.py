import taichi.math as tm
import math
import taichi as ti
import random
from voxypy.models import Entity, Voxel
import PIL.Image as im


ti.init(arch=ti.vulkan)

vec3 = ti.math.vec3




entity = Entity().from_file("ffp\\haus.vox")


print(entity.get(1,1,1))

xmax = 0

for x in range(len(entity.all_voxels())):
    try:
        (entity.get(x,0,0))
    except:
        xmax = x
        break
ymax = 0

for y in range(len(entity.all_voxels())):
    try:
        (entity.get(0,y,0))
    except:
        ymax = y
        break
zmax = 0

for z in range(len(entity.all_voxels())):
    try:
        (entity.get(0,0,z))
    except:
        zmax = z
        break




@ti.func
def get_hitpoint(o, d, t):
    hitpoint = o + t * d
    return hitpoint

@ti.dataclass
class Voxel:
    min: vec3
    max: vec3
    color: vec3
    ref: bool

@ti.dataclass
class hit:
    d: ti.types.f32
    cord: tm.vec3
    normal: vec3


@ti.func
def ray_color(ray_origin, ray_direction):
    t = 0.5 * (tm.normalize(ray_direction).y + 1)
    return ((1.0 - t) * tm.vec3(1,1,1) + t * tm.vec3(0.5, 0.7, 1.0))
    #return vec3(0)


@ti.func
def random_in_unit_sphere():
  theta = 2.0 * 3.14 * ti.random()
  phi = ti.acos((2.0 * ti.random()) - 1.0)
  r = ti.pow(ti.random(), 1.0 / 3.0)
  return ti.Vector([r * ti.sin(phi) * ti.cos(theta), r * ti.sin(phi) * ti.sin(theta), r * ti.cos(phi)])



eps = 1e-4
inf = 1e10

image_width = 1366
image_height = 768

aspect = image_width/image_height

viewport_height = 2
viewport_width = aspect * viewport_height
focal_length = 2

origin = tm.vec3(0.0, 0.0, 0.0)
horizontal = tm.vec3(viewport_width, 0, 0)
vertical = tm.vec3(0, viewport_height, 0)
lower_left_corner = origin - horizontal / 2 - vertical / 2 - tm.vec3(0, 0, focal_length)

texture = ti.field(dtype=tm.vec3, shape=(16, 16))

im = im.open('ffp\grass_block_side.png')
rgb_im = im.convert('RGB')



for x in range(16):
    for y in range(16):
        r, g, b = rgb_im.getpixel((x, y))
        texture[x,y] = vec3(r,g,b) / 255



voxel_arr = []

s = 10000

voxels = Voxel.field(shape=(s))




print(zmax)

palette = entity.get_palette()

chunk = ti.field(dtype=ti.types.i32, shape=(xmax,zmax,ymax))
color = ti.field(dtype=vec3, shape=(xmax,zmax,ymax))
dmap = ti.field(dtype=vec3, shape=(xmax,zmax,ymax))

for x in range(xmax):
    for y in range(ymax):
        for z in range(zmax):
            if(entity.get(x,y,z) != 0):
                chunk[x,z,y] = 1
                f = vec3(palette[entity.get(x,y,z)._color][0],palette[entity.get(x,y,z)._color][1],palette[entity.get(x,y,z)._color][2])/255
                color[x,z,y] = f
                print(str(x) + " " + str(y) + " " + str(z))


print("loaded")
@ti.func
def get_cube_normal(nx, ny, nz):
    max_comp = tm.max(abs(nx), abs(ny), abs(nz))
    normal = vec3(0)
    if max_comp == abs(nx):
        normal = vec3(tm.sign(nx), 0, 0)
    elif max_comp == abs(ny):
        normal = vec3(0, tm.sign(ny), 0)
    elif max_comp == abs(nz):
        normal = vec3(0, 0, tm.sign(nz))
    return normal













@ti.func
def ShapeMarch(p0, d):
    maxDistToCheck = 100
    voxelGridSize = 1
    t = 0.0
    depth = 0.0

    while t <= maxDistToCheck:
        p = p0 + d * t
        f = p / voxelGridSize
        shapeValue = chunk[int(p.x), int(p.y), int(p.z)]
        
        if shapeValue == 1:
            depth = t
            break

        deltas = (tm.step(0.0, d) - tm.fract(p)) / d
        t = t + max(tm.min(deltas) + float(shapeValue), eps)

    return depth




@ti.func
def intersection(o, d):
    d = tm.normalize(d)
    X = int(tm.round(o.x))
    Y = int(tm.round(o.y))
    Z = int(tm.round(o.z))

    stepX = int(tm.sign(d.x))
    stepY = int(tm.sign(d.y))
    stepZ = int(tm.sign(d.z))

    tMaxX = (X + (0.5 if stepX > 0 else -0.5) - o.x) / d.x
    tMaxY = (Y + (0.5 if stepY > 0 else -0.5) - o.y) / d.y
    tMaxZ = (Z + (0.5 if stepZ > 0 else -0.5) - o.z) / d.z
    tMax = 0.0
    tDeltaX = abs(1 / d.x)
    tDeltaY = abs(1 / d.y)
    tDeltaZ = abs(1 / d.z)

    voxel = 0
    D = 0.0 

    for i in range(100):
        if tMaxX < tMaxY and tMaxX < tMaxZ:
            tMax = tMaxX
            X += stepX
            tMaxX += tDeltaX
            if X == xmax or X < 0:
                break
        elif tMaxY < tMaxZ:
            tMax = tMaxY
            Y += stepY
            tMaxY += tDeltaY
            if Y == ymax or Y < 0:
                break
        else:
            tMax = tMaxZ
            Z += stepZ
            tMaxZ += tDeltaZ
            if Z == zmax or Z < 0:
                break

        voxel = chunk[X, Y, Z] if 0 <= X < xmax and 0 <= Y < ymax and 0 <= Z < zmax else 0
        if voxel > 0:
            break

    if voxel > 0:
        D = tMax
    else:
        D = 0

    return hit(cord=o+d*(D-0.001), d=D, normal=get_normal(vec3(X,Y,Z)-(o+d*D))*-1)









@ti.func
def get_normal(surface_normal):
    maximum = 0.0
    index = 0
    for i in range(3):
        if ti.abs(surface_normal[i]) > ti.abs(maximum):
            index = i
            maximum = surface_normal[i]
    surface_normal = vec3(0)
    surface_normal[index] = maximum
    return surface_normal


pixels = ti.field(dtype=tm.vec3, shape=(image_width, image_height))
buff = ti.field(dtype=tm.vec3, shape=(image_width, image_height))
blur = ti.field(dtype=tm.vec3, shape=(image_width, image_height))
final = ti.field(dtype=tm.vec3, shape=(image_width, image_height))

albedo = ti.field(dtype=tm.vec3, shape=(image_width, image_height))
normals = ti.field(dtype=tm.vec3, shape=(image_width, image_height))
depth = ti.field(dtype=tm.vec3, shape=(image_width, image_height))
diffuse = ti.field(dtype=tm.vec3, shape=(image_width, image_height))
hit_point = ti.field(dtype=tm.vec3, shape=(image_width, image_height))
sky = ti.field(dtype=tm.vec3, shape=(image_width, image_height))
@ti.func
def gbuff(o,d,i,j):
    hitrecord = intersection(o=o, d=d)
    if hitrecord.d > 0 and hitrecord.d != inf:
        x = int(ti.round(hitrecord.cord.x))
        y = int(ti.round(hitrecord.cord.y))
        z = int(ti.round(hitrecord.cord.z))
        f = vec3(x - hitrecord.cord.x + 0.5, y - hitrecord.cord.y + 0.5, z - hitrecord.cord.z + 0.5) * 16
        albedo[i,j] = texture[int(f.x),int(f.y)]
        normal = hitrecord.normal

        normals[i,j] = hitrecord.normal
        depth[i,j] = hitrecord.d 
        hit_point[i,j] = hitrecord.cord
    else:
        c = ray_color(ray_origin=o, ray_direction=d)  
        depth[i, j] = vec3(0)
        normals[i, j] = vec3(0)
        albedo[i,j] = vec3(inf)
        hit_point[i,j] = vec3(0)

@ti.func
def render_diffuse(o, d, i, j):
    c = vec3(1)
    normal = normals[i, j]
    o = hit_point[i,j]
    d = (random_in_unit_sphere() + normal)
    if(depth[i,j].x > 0):
        for b in range(10):
            hitrecord = intersection(o=o, d=d)
            if hitrecord.d > 0 and hitrecord.d != inf:
                if(b == 9):
                    c = vec3(0)
                else:
                    x = int(ti.round(hitrecord.cord.x))
                    y = int(ti.round(hitrecord.cord.y))
                    z = int(ti.round(hitrecord.cord.z))
                    f = vec3(x - hitrecord.cord.x + 0.5, y - hitrecord.cord.y + 0.5, z - hitrecord.cord.z + 0.5) * 16
                    c = c * (texture[int(f.x), int(f.y)]) * (1 / hitrecord.d*hitrecord.d)
                    normal = hitrecord.normal                    
                    o = hitrecord.cord + (normal * 0.01)  # Move the origin to the hit point
                    d = ((random_in_unit_sphere() + normal))
                    d = tm.normalize(d)  # Generate a random direction for the next ray
            else:
                c = c * ray_color(ray_origin=o,ray_direction=d)
                break
    else:
        c = vec3(0)
    return c

@ti.func
def render_specular(o, d, i, j):
    c = vec3(1)
    normal = normals[i, j]
    o = hit_point[i,j]
    d = tm.reflect(x=d,n=normal*-1)
    if(depth[i,j].x > 0):
        for b in range(2):
            hitrecord = intersection(o=o, d=d)
            if hitrecord.d > 0 and hitrecord.d != inf:
                if(b == 1):
                    c = vec3(0)
                else:
                    x = int(ti.round(hitrecord.cord.x))
                    y = int(ti.round(hitrecord.cord.y))
                    z = int(ti.round(hitrecord.cord.z))
                    normal = hitrecord.normal       
                    f = vec3(x - hitrecord.cord.x + 0.5, y - hitrecord.cord.y + 0.5, z - hitrecord.cord.z + 0.5) * 16
                    o = hitrecord.cord  + (normal*0.1)  # Move the origin to the hit point
                    d = tm.reflect(x=d,n=normal*-1)
                    c = c * (texture[int(f.x), int(f.y)])
                    
            else:
                c = c * ray_color(ray_origin=o,ray_direction=d)
                break
    else:
        c = vec3(0)
    return c



@ti.func
def trace(o, d, i, j):
    c = vec3(1)
    normal = vec3(0)
    for b in range(1):
        hitrecord = intersection(o=o, d=d)
        if hitrecord.d > 0 and hitrecord.d != inf:
            x = int(ti.round(hitrecord.cord.x))
            y = int(ti.round(hitrecord.cord.y))
            z = int(ti.round(hitrecord.cord.z))
            #c = c * color[x,y,z]
            f = vec3(x-hitrecord.cord.x+0.5,y-hitrecord.cord.y+0.5,z-hitrecord.cord.z+0.5)*16
            c = c * texture[int(f.x),int(f.y)]
            normal = hitrecord.normal
            o = hitrecord.cord + (normal * 0) # Move the origin to the hit point
            d =  (tm.reflect(x=d,n=normal) * 1) + ((random_in_unit_sphere() + normal) * 0.1)
            d = tm.normalize(d)  # Generate a random direction for the next ray
            if(b==0):
                normals[i,j] = normal
                depth[i,j] = (16 - hitrecord.d) / 16 
        else:
            c = c * ray_color(ray_origin=o, ray_direction=d)  
            if(b==0):
                depth[i, j] = vec3(0)
                normals[i, j] = vec3(0)
            break
    return c




@ti.kernel
def paint(o: vec3,w: int):
    for i, j in pixels:
        u = i / (image_width - 1)
        v = j / (image_height - 1)
        d =  lower_left_corner + u * horizontal + v * vertical 
        dif = vec3(0)
        gbuff(o=o,d=d,i=i,j=j)
        for s in range(2):
            dif += render_diffuse(o=o,d=d,i=i,j=j) 
        diffuse[i,j] = dif / 2 # render_specular(o,d,i,j)
        if(hit_point[i,j].x == 0 and hit_point[i,j].y == 0 and hit_point[i,j].z == 0):
            sky[i,j]=ray_color(ray_origin=o,ray_direction=d)
        else:
            sky[i,j]= vec3(0)

    for i, j in pixels:
            pixels[i,j] = albedo[i,j] * diffuse[i,j] + sky[i,j]
    
    
gui = ti.GUI("render", res=(image_width, image_height),fast_gui=True)
diffuse_gui = ti.GUI("diffuse", res=(image_width, image_height),fast_gui=False)

w = 1



print(xmax)
print(ymax)
print(zmax)
while gui.running:
    gui.get_event()  # must be called before is_pressed
    if gui.is_pressed('a', ti.GUI.LEFT):
        origin.x += - 0.1
    elif gui.is_pressed('d', ti.GUI.RIGHT):
        origin.x += 0.1
    elif gui.is_pressed('w', ti.GUI.UP):
        origin.z += - 0.1
    elif gui.is_pressed('s', ti.GUI.DOWN):
        origin.z += 0.1
    
    origin.y = 5
    gui.show()
    paint(origin,w=w+1)
    gui.set_image(pixels)
    gui.show()
    diffuse_gui.set_image(albedo)
    diffuse_gui.show()
    w += 1